
# HassanIsa_M6Ex3.py
# Study Tracker Application
# Author: Hassan Isa
# This app allows students to log study sessions, view a summary, and stay motivated

import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk

# ------------------ GLOBAL VARIABLES ------------------ #
study_sessions = []  # Store all study session logs


# ------------------ MAIN APPLICATION CLASS ------------------ #
class StudyTrackerApp(tk.Tk):
    """Main window for logging study sessions"""
    def __init__(self):
        super().__init__()
        self.title("Study Tracker")
        self.geometry("400x400")
        self.configure(bg="#f0f8ff")

        # Motivational image in main window
        self.motiv_img = Image.open("motivation1.png")  # Replace with your image file
        self.motiv_img = self.motiv_img.resize((100, 100))
        self.motiv_imgtk = ImageTk.PhotoImage(self.motiv_img)
        tk.Label(self, image=self.motiv_imgtk, bg="#f0f8ff").pack(pady=10)

        # Labels and Entry Fields
        tk.Label(self, text="Subject/Topic:", bg="#f0f8ff").pack()
        self.subject_entry = tk.Entry(self, width=30)
        self.subject_entry.pack(pady=5)

        tk.Label(self, text="Time Spent (minutes):", bg="#f0f8ff").pack()
        self.time_entry = tk.Entry(self, width=30)
        self.time_entry.pack(pady=5)

        tk.Label(self, text="Notes (Optional):", bg="#f0f8ff").pack()
        self.notes_entry = tk.Entry(self, width=30)
        self.notes_entry.pack(pady=5)

        # Buttons
        tk.Button(self, text="Log Study Session", command=self.log_session).pack(pady=5)
        tk.Button(self, text="View Summary", command=self.open_summary_window).pack(pady=5)
        tk.Button(self, text="Exit", command=self.quit).pack(pady=5)

    def log_session(self):
        """Validate inputs and log the study session"""
        subject = self.subject_entry.get().strip()
        time_spent = self.time_entry.get().strip()

        # Input validation
        if not subject:
            messagebox.showerror("Input Error", "Subject/Topic cannot be empty.")
            return
        if not time_spent.isdigit() or int(time_spent) <= 0:
            messagebox.showerror("Input Error", "Time spent must be a positive number.")
            return

        notes = self.notes_entry.get().strip()
        session = {"subject": subject, "time": int(time_spent), "notes": notes}
        study_sessions.append(session)
        messagebox.showinfo("Success", f"Study session for '{subject}' logged!")

        # Clear fields
        self.subject_entry.delete(0, tk.END)
        self.time_entry.delete(0, tk.END)
        self.notes_entry.delete(0, tk.END)

    def open_summary_window(self):
        """Open a new window showing summary of study sessions"""
        if not study_sessions:
            messagebox.showwarning("No Data", "No study sessions logged yet!")
            return

        summary_window = SummaryWindow(self)
        summary_window.mainloop()


# ------------------ SUMMARY WINDOW CLASS ------------------ #
class SummaryWindow(tk.Toplevel):
    """Displays total study time and subjects"""
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Study Summary")
        self.geometry("400x400")
        self.configure(bg="#fffaf0")

        # Second motivational image
        self.summary_img = Image.open("motivation2.png")  # Replace with your image file
        self.summary_img = self.summary_img.resize((100, 100))
        self.summary_imgtk = ImageTk.PhotoImage(self.summary_img)
        tk.Label(self, image=self.summary_imgtk, bg="#fffaf0").pack(pady=10)

        # Calculate summary
        total_time = sum(s["time"] for s in study_sessions)
        total_sessions = len(study_sessions)
        subjects = ", ".join(set(s["subject"] for s in study_sessions))

        # Display summary
        summary_text = (
            f"Total Study Time: {total_time} minutes\n"
            f"Total Sessions: {total_sessions}\n"
            f"Subjects Covered: {subjects}"
        )
        tk.Label(self, text=summary_text, bg="#fffaf0", font=("Arial", 12)).pack(pady=10)

        tk.Button(self, text="Close", command=self.destroy).pack(pady=5)


# ------------------ RUN APPLICATION ------------------ #
if __name__ == "__main__":
    app = StudyTrackerApp()
    app.mainloop()
